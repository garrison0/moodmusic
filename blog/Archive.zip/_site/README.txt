this website is to procure employment

and put some of my stuff out there

but really to procure employment

(please)